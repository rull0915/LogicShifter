#include "LogicCircuit.h"
#include "CircuitEditer.h"

#include <bitset>

LogicCircuit::LogicCircuit()
	: m_cells{}
	, m_nextCells{}
	, m_circuitEditer{ m_cells }
	, m_circuitSimulator{ m_cells, m_nextCells }
	, m_textBox{}
{
}

void LogicCircuit::Initialize()
{
	m_circuitSimulator.Initialize();

	// �{�^���̒ǉ�
	for(auto button : buttonInfos)
	{
		auto b = Button(button.second.first, BUTTON_SIZE, true, m_ghIcons[button.first]);
		m_playButtons[button.first] = std::make_unique<Button>(std::move(b));
	}
}

void LogicCircuit::Update(float elapsedTime, Vector2D cameraPos, float cameraScale)
{
	m_circuitEditer.Update(elapsedTime);

	// �{�^����ɂȂ���
	bool mouseIsOnButton = false;
	for (auto& button : m_playButtons) if (button.second->MouseIsOnButton()) mouseIsOnButton = true;

	if ((MouseDown() & MOUSE_INPUT_LEFT) != 0 && !mouseIsOnButton) m_circuitEditer.Push(m_mousePos, cameraPos, cameraScale);
	// �}�E�X�̍��N���b�N������Ă�����
	else if ((MouseEnter() & MOUSE_INPUT_LEFT) != 0 && !mouseIsOnButton)
	{
		// �}�E�X�̈ʒu�ɃZ����ݒu
		m_circuitEditer.PutCell(m_mousePos, cameraPos, cameraScale);
	}
	// �}�E�X�̉E�N���b�N������Ă�����
	if ((MouseEnter() & MOUSE_INPUT_RIGHT) != 0 && !mouseIsOnButton)
	{
		// �}�E�X�̈ʒu�ɃZ����ݒu
		m_circuitEditer.DeleteCell(m_mousePos, cameraPos, cameraScale);
	}

	// �}�E�X�̍��N���b�N���I�������
	if (MouseUp() & MOUSE_INPUT_LEFT)
	{
		m_circuitEditer.DecideCell(m_mousePos, cameraPos, cameraScale);
	}

	m_textBox.Update(false, { -1, -1 }, L"");
	// �{�^���̍X�V
	for(auto& button : m_playButtons)
	{
		button.second->Update();

		// �{�^���������ꂽ�Ƃ��̏���
		if(button.second->GetIsPressed())
		{
			if (button.first == "Play") 
			{
				m_playSpeed = UPDATE_DISTANCE_FAST;
				m_circuitEditer.ChangeUIState(State::Closing);
			}
			else if (button.first == "PlayFast")
			{
				m_playSpeed = UPDATE_DISTANCE_FASTTEST;
				m_circuitEditer.ChangeUIState(State::Closing);
			}
			else if (button.first == "Stop")m_playSpeed = INT_MAX;
			else if(button.first == "PlayOnce")
			{
				m_playSpeed = INT_MAX;
				m_circuitSimulator.ToNextCells();
			}

			m_nowElapsedTime = 0;
		}

		if(button.second->MouseIsOnButton()) 
		{
			m_textBox.Update(true, { m_mousePos.x + 0.f, m_mousePos.y + 0.f }, buttonInfos[button.first].second);
		}
	}

	// ���Ԃ̉��Z
	m_nowElapsedTime += elapsedTime;

	if(m_nowElapsedTime > m_playSpeed)
	{
		if (m_playSpeed == UPDATE_DISTANCE_FASTTEST) for (int i = 0; i < 4; i++) m_circuitSimulator.ToNextCells();

		m_circuitSimulator.ToNextCells();
		m_nowElapsedTime = 0;
	}
}

void LogicCircuit::Render(Vector2DInt mouseInput, Vector2D cameraPos, float scale)
{
	// �w�i�`��
	DrawBox(0, 0, Screen::WIDTH, Screen::HEIGHT, 0x111111, true);

	// �Y�[�����S�␳
	float offsetX = Screen::WIDTH / 2 + Screen::WIDTH / 2 * scale;
	float offsetY = Screen::HEIGHT / 2 + Screen::HEIGHT / 2 * scale;

	// �Z���̕`��
	for (const auto& cell : m_cells)
	{
		int color = Cell::COLORS[{ GetType(cell.second), GetSubType(cell.second) }];

		if((GetType(cell.second) == TYPE_WIRE && GetSubType(cell.second) == SUBTYPE_NORMAL) && (GetDownSignal(cell.second) || GetLeftSignal(cell.second) || GetUpSignal(cell.second) || GetRightSignal(cell.second))) color = 0xAAAAAA;
		
		if ((cell.first.x) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX > Screen::WIDTH || (cell.first.x + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX < 0)continue;
		if ((cell.first.y) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY > Screen::HEIGHT || (cell.first.y + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY < 0)continue;

		// �`��
		DrawBox(
			(cell.first.x) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
			(cell.first.y) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
			(cell.first.x + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
			(cell.first.y + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
			color,
			true
		);
	}

	// �O���b�h
	DrawGrid(cameraPos, scale);

	m_circuitEditer.Render(mouseInput, cameraPos, scale);

	// �����Z�����̕`��
	DrawFormatStringToHandle(20, Screen::HEIGHT - 20 - 28, 0xffffff, GetFontHandle(28), L"���݂̃Z����: %d", m_cells.size());

	DrawBox(70 - BUTTON_SIZE.x / 2 - 10, 70 - BUTTON_SIZE.y / 2 - 10, 250 + BUTTON_SIZE.x / 2 + 10, 70 + BUTTON_SIZE.y / 2 + 10, 0x777777, true);
	// ���s�{�^���̕`��
	for (auto& button : m_playButtons) button.second->Render();

	m_textBox.Render(true);

	// �e�Z�����̕`��
	int i = 0;
	for(auto cell : m_cells)
	{
		DrawFormatString(0, 100 + i * 30, 0xffffff, L"x: %d y: %d\n cell: %x", cell.first.x, cell.first.y, cell.second);
		i++;
	}
}

// �O���b�h�`��
void LogicCircuit::DrawGrid(Vector2D cameraPos, float scale)
{
	const int blockPixel = static_cast<int>(BLOCK_SIZE * scale);

	// �J�����̍��オ�ǂ̃Z���������߂�
	float offsetX = Screen::WIDTH / 2 + Screen::WIDTH / 2 * scale;
	float offsetY = Screen::HEIGHT / 2 + Screen::HEIGHT / 2 * scale;

	int startCellX = (0 + cameraPos.x - offsetX) / (blockPixel)-1;
	int startCellY = (0 + cameraPos.y - offsetY) / (blockPixel)-1;

	// ��ʂɉ��}�X�`���Ώ\����
	int cellCountX = Screen::WIDTH / blockPixel + 2;
	int cellCountY = Screen::HEIGHT / blockPixel + 2;

	// ������̐F�i���������ۂ��j
	int gridColor = 0;

	// �c����`��
	for (int i = 0; i <= cellCountX; i++)
	{
		if ((startCellX + i) % 5 == 0)
		{
			if (blockPixel < 8) continue;
			gridColor = GetColor(200, 200, 200);
		}
		else
		{
			if (blockPixel < 15) continue;
			gridColor = GetColor(100, 100, 100);
		}

		int x = (startCellX + i) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX;

		DrawLine(x, 0, x, Screen::HEIGHT, gridColor);
	}

	// ������`��
	for (int j = 0; j <= cellCountY; j++)
	{
		if ((startCellY + j) % 5 == 0)
		{
			if (blockPixel < 8) continue;
			gridColor = GetColor(200, 200, 200);
		}
		else
		{
			if (blockPixel < 15) continue;
			gridColor = GetColor(100, 100, 100);
		}

		int y = (startCellY + j) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY;

		DrawLine(0, y, Screen::WIDTH, y, gridColor);
	}
}
