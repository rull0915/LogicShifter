#include "CircuitEditer.h"

CircuitEditer::CircuitEditer(std::unordered_map<Vector2DInt, PackedCell>& cells)
	: m_cells{ cells }
	, m_nowPutMode{ PutMode::Put }
	, m_nowPutType{ TYPE_WIRE, SUBTYPE_NORMAL }
	, m_cursorSize{ 1, 1 }
	, m_selectionStart{ false }
	, m_selectionPos{ {0, 0}, {0, 0} }
	, m_canPut{ false }
	, m_copyStart{ false }
	, m_copyPos{ {0, 0}, {0, 0}}
	, m_copyCells{}
	, m_selectUi{ this }
{
}

// �X�V����
void CircuitEditer::Update(float elapsedTime)
{
	m_selectUi.Update(elapsedTime);
}

void CircuitEditer::Render(Vector2DInt mouseInput, Vector2D cameraPos, float scale)
{			  
	// �J�[�\���̕`��
	CursorRender(mouseInput, cameraPos, scale);

	// �Y�[�����S�␳
	float offsetX = Screen::WIDTH / 2 + Screen::WIDTH / 2 * scale;
	float offsetY = Screen::HEIGHT / 2 + Screen::HEIGHT / 2 * scale;

	switch (m_nowPutMode)
	{
	case PutMode::Put:
		// �J�[�\���`��
		break;
	case PutMode::Copy:
		if (m_copyStart)
		{
			// �R�s�[�͈͕`��
			DrawBox(
				(m_copyPos.first.x) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(m_copyPos.first.y) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				(m_copyPos.second.x + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(m_copyPos.second.y + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				0x770000,
				false, 3
			);
		}
		break;
	case PutMode::Paste:

		// �}�E�X�̃Z���ʒu
		Vector2DInt pos = GetCellIndex(mouseInput, cameraPos, scale);

		SetDrawBlendMode(DX_BLENDMODE_ALPHA, 128);
		// �v���r���[�`��
		for (const auto& cell : m_copyCells)
		{
			int color = Cell::COLORS[{GetType(cell.second), GetSubType(cell.second)}];

			// �`��
			DrawBox(
				(cell.first.x + pos.x) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(cell.first.y + pos.y) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				(cell.first.x + pos.x + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(cell.first.y + pos.y + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				color,
				true
			);
		}
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

		break;

	case PutMode::Range:

		if (m_selectionStart)
		{
			// �I��͈͕`��
			DrawBox(
				(m_selectionPos.first.x) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(m_selectionPos.first.y) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				(GetCellIndex(mouseInput, cameraPos, scale).x + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(GetCellIndex(mouseInput, cameraPos, scale).y + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				0x770000,
				false, 3
			);
		}

		break;
	default:
		break;
	}

	// UI�̕`��
	m_selectUi.Render();
}

void CircuitEditer::PutCell(Vector2DInt mousePos, Vector2D cameraPos, float scale)
{
	if (!m_canPut) return;

	Vector2DInt cellPos = GetCellIndex(mousePos, cameraPos, scale);

	switch (m_nowPutMode)
	{
	case PutMode::Put:

		for (int i = 0; i < m_cursorSize.y; i++)
		{
			for (int j = 0; j < m_cursorSize.x; j++)
			{
				if (m_cells.find({ cellPos.x - j, cellPos.y - i }) == m_cells.end())
				{
					PackedCell C = 0;
					SetType(C, m_nowPutType.first);
					SetSubType(C, m_nowPutType.second);

					m_cells[{ cellPos.x - j, cellPos.y - i }] = C;
				}
			}
		}

		break;
	case PutMode::Copy:

		m_copyPos.second = cellPos;

		break;
	case PutMode::Paste:
		break;
	default:
		break;
	}
}

void CircuitEditer::DecideCell(Vector2DInt mousePos, Vector2D cameraPos, float scale)
{
	Vector2DInt cellPos = GetCellIndex(mousePos, cameraPos, scale);

	// UI�Ƃ̔��`�F�b�N
	if (m_selectUi.GetInSelectUI(mousePos)) return;

	if (m_nowPutMode == PutMode::Copy && m_copyStart)
	{
		Vector2DInt min = m_copyPos.second, max = m_copyPos.first;

		m_copyPos.second = cellPos;

		m_copyCells.clear();

		for (auto cell : m_cells)
		{
			// �Z�����R�s�[�͈͓��ł����
			if ((cell.first.x >= m_copyPos.first.x && cell.first.x <= m_copyPos.second.x) && (cell.first.y >= m_copyPos.first.y && cell.first.y <= m_copyPos.second.y))
			{
				if (min.x > cell.first.x) min.x = cell.first.x;
				if (min.y > cell.first.y) min.y = cell.first.y;
				if (max.x < cell.first.x) max.x = cell.first.x;
				if (max.y < cell.first.y) max.y = cell.first.y;
			}
		}

		// �ݒu���[�h�����Z�b�g
		m_nowPutMode = PutMode::Put;
		m_copyStart = false;

		m_copyPos.first = min;
		m_copyPos.second = max;

		for (auto cell : m_cells)
		{
			if ((cell.first.x >= m_copyPos.first.x && cell.first.x <= m_copyPos.second.x) && (cell.first.y >= m_copyPos.first.y && cell.first.y <= m_copyPos.second.y))
			{
				// �����̃��[�J�����W
				m_copyCells[cell.first - m_copyPos.first] = cell.second;
			}
		}
	}
	else if (m_nowPutMode == PutMode::Range && m_selectionStart)
	{
		// �I��͈͂̉E��
		m_selectionPos.second = { cellPos.x + 1, cellPos.y + 1 };

		// �T�C�Y����
		m_cursorSize = m_selectionPos.second - m_selectionPos.first;

		m_nowPutMode = PutMode::Put;

		m_selectionStart = false;
	}
}

void CircuitEditer::DeleteCell(Vector2DInt mousePos, Vector2D cameraPos, float scale)
{
	Vector2DInt cellPos = GetCellIndex(mousePos, cameraPos, scale);

	for (int i = 0; i < m_cursorSize.y; i++)
	{
		for (int j = 0; j < m_cursorSize.x; j++)
		{
			m_cells.erase({ cellPos.x - j, cellPos.y - i });
		}
	}
}

void CircuitEditer::Push(Vector2DInt mousePos, Vector2D cameraPos, float scale)
{
	// UI�Ƃ̔��`�F�b�N
	m_canPut = !m_selectUi.GetInSelectUI(mousePos);

	// �Y�[�����S�␳
	int x = GetCellIndex(mousePos, cameraPos, scale).x;
	int y = GetCellIndex(mousePos, cameraPos, scale).y;

	if (!m_canPut) return;

	PackedCell c = m_cells[{x, y}];

	switch (m_nowPutMode)
	{
	case PutMode::Put:

		if ((m_cells.find({ x, y }) != m_cells.end())
			&& (GetType(c) == TYPE_OTHERS && GetSubType(c) == SUBTYPE_BUTTON))
		{
			SetDownSignal	(c, !GetDownSignal(c));
			SetUpSignal		(c, !GetUpSignal(c));
			SetRightSignal	(c, !GetRightSignal(c));
			SetLeftSignal	(c, !GetLeftSignal(c));

			m_cells[{x, y}] = c;
		}

		break;
	case PutMode::Copy:

		m_copyStart = true;
		m_copyPos.first = { x, y };

		break;
	case PutMode::Paste:

		for (auto cell : m_copyCells)
		{
			// �R�s�[
			m_cells[Vector2DInt{ cell.first.x + x,cell.first.y + y }] = cell.second;
		}

	case PutMode::Range:

		// �I��͈͂̍��������
		m_selectionPos.first = { x, y };

		m_selectionStart = true;

		break;

		break;
	default:
		break;
	}
}

void CircuitEditer::Reset()
{
	m_cells.clear();
}

void CircuitEditer::CursorRender(Vector2DInt mousePos, Vector2D cameraPos, float scale)
{
	Vector2DInt cursorCell = GetCellIndex(mousePos, cameraPos, scale);

	// �Y�[�����S�␳
	float offsetX = Screen::WIDTH / 2 + Screen::WIDTH / 2 * scale;
	float offsetY = Screen::HEIGHT / 2 + Screen::HEIGHT / 2 * scale;

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 64);

	// ������
	for (int i = 0; i < m_cursorSize.y; i++)
	{
		for (int j = 0; j < m_cursorSize.x; j++)
		{
			DrawBox(
				(cursorCell.x - j) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(cursorCell.y - i) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				(cursorCell.x - j + 1) * (BLOCK_SIZE * scale) - cameraPos.x + offsetX,
				(cursorCell.y - i + 1) * (BLOCK_SIZE * scale) - cameraPos.y + offsetY,
				0xffffff,
				true
			);
		}
	}

	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}

void CircuitEditer::SaveCells(std::wstring fileName)
{
	// �t�@�C���֏�������
	std::ofstream file(fileName);

	if (file.is_open())
	{
		// �S�ẴZ����ۑ�
		for (auto cell : m_cells)
		{
			file << cell.first.x << ',' << cell.first.y << ',' << (cell.second & 0b11110000) << '\n';
		}
	}
}

void CircuitEditer::LoadCells(std::wstring fileName)
{
	// �Z���̃��Z�b�g
	m_cells.clear();

	// �t�@�C������ǂݍ���
	std::ifstream ifs(fileName);
	std::string line;

	PackedCell cell;
	Vector2DInt pos;

	while (std::getline(ifs, line))
	{
		std::istringstream iss(line);

		// �J���}��؂�ŕ�������
		std::string item;

		getline(iss, item, ',');
		pos.x = std::stoi(item);

		getline(iss, item, ',');
		pos.y = std::stoi(item);

		// �^�C�v
		getline(iss, item, ',');
		cell = stoi(item);

		m_cells[pos] = cell;
	}

	// �t�@�C�����N���[�Y
	ifs.close();
}

// �R�s�[�Z���̔��]
void CircuitEditer::CopyInversion(bool horizontal)
{
	auto save = m_copyCells;

	m_copyCells.clear();

	for (auto cell : save)
	{
		Vector2DInt pos;
		if (horizontal)
		{
			pos = { (m_copyPos.second.x - m_copyPos.first.x) - cell.first.x, cell.first.y };
		}
		else
		{
			pos = { cell.first.x, (m_copyPos.second.y - m_copyPos.first.y) - cell.first.y };
		}
		m_copyCells[pos] = cell.second;
	}
}
