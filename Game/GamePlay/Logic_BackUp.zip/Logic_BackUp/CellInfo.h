#pragma once
#include "Cell.h"

// �Z���T�C�Y
static constexpr int BLOCK_SIZE = 64;

namespace Cell
{

	// ���݂���{�^���̎��
	static std::vector<std::pair<CellType, CellSubType>> BUTTONS
	{
			{TYPE_WIRE,   SUBTYPE_NORMAL},
			{TYPE_WIRE,   SUBTYPE_CROSS},
			{TYPE_OTHERS, SUBTYPE_BUTTON},
			{TYPE_INPUT,  SUBTYPE_AND},
			{TYPE_INPUT,  SUBTYPE_OR},
			{TYPE_INPUT,  SUBTYPE_XOR},
			{TYPE_OUTPUT, SUBTYPE_NORMAL},
			{TYPE_OUTPUT, SUBTYPE_NOT},
	};

	// �F
	static std::map<std::pair<CellType, CellSubType>, int> COLORS
	{
			{{TYPE_WIRE,   SUBTYPE_NORMAL}, 0x555555},
			{{TYPE_WIRE,   SUBTYPE_CROSS}, 0x77ff77},
			{{TYPE_OTHERS, SUBTYPE_BUTTON}, 0x7777ff},
			{{TYPE_INPUT,  SUBTYPE_AND}, 0xff7777},
			{{TYPE_INPUT,  SUBTYPE_OR},  0xffff77},
			{{TYPE_INPUT,  SUBTYPE_XOR}, 0xff77ff},
			{{TYPE_OUTPUT, SUBTYPE_NORMAL}, 0x77ffff},
			{{TYPE_OUTPUT, SUBTYPE_NOT},  0xFBB161},
	};
}

inline Vector2DInt GetCellIndex(Vector2DInt screenPos, Vector2D cameraPos, float scale)
{
	// �Y�[�����S�␳
	float offsetX = Screen::WIDTH / 2 + Screen::WIDTH / 2 * scale;
	float offsetY = Screen::HEIGHT / 2 + Screen::HEIGHT / 2 * scale;

	int x = (screenPos.x + cameraPos.x - offsetX) / (BLOCK_SIZE * scale);
	int y = (screenPos.y + cameraPos.y - offsetY) / (BLOCK_SIZE * scale);

	if (x <= 0)
	{
		if (x == 0) (screenPos.x + cameraPos.x - offsetX) / (BLOCK_SIZE * scale) < 0 ? x-- : x;
		else x--;
	}
	if (y <= 0)
	{
		if (y == 0) (screenPos.y + cameraPos.y - offsetY) / (BLOCK_SIZE * scale) < 0 ? y-- : y;
		else y--;
	}

	return Vector2DInt{ x, y };
}
