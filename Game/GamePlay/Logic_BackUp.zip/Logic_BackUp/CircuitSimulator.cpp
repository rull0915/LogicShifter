#include "CircuitSimulator.h"

CircuitSimulator::CircuitSimulator(std::unordered_map<Vector2DInt, PackedCell>& cells, std::unordered_map<Vector2DInt, PackedCell>& nextCells)
	: m_cells{ cells }
	, m_nextCells{ nextCells }
	, devCells{ nullptr }
	, devNextCells{ nullptr }
{
	size_t size = 2048 * 2048 * sizeof(PackedCell);

	cudaMalloc(&devCells, size);
	cudaMalloc(&devNextCells, size);
}

void CircuitSimulator::Initialize()
{
}

void CircuitSimulator::ToNextCells()
{

	// m_nextCells�̊m��
	m_nextCells.clear();

	// ----- map��vector�ɕϊ� ----- //
	m_cellsVec.clear();

	// �T�C�Y�𒲂ׂ�
	int minX = INT_MAX, minY = INT_MAX, maxX = INT_MIN, maxY = INT_MIN;

	for (auto& cell : m_cells)
	{
		minX = cell.first.x < minX ? cell.first.x : minX;
		minY = cell.first.y < minY ? cell.first.y : minY;
		maxX = cell.first.x > maxX ? cell.first.x : maxX;
		maxY = cell.first.y > maxY ? cell.first.y : maxY;
	}

	int WIDTH = (maxX - minX + 1), HEIGHT = (maxY - minY + 1);
	if (minX == INT_MAX) {WIDTH = 0; HEIGHT = 0;}

	// �m��
	m_cellsVec.resize(WIDTH * HEIGHT);
	m_nextCellsVec.resize(WIDTH * HEIGHT);

	// ���߂�
	PackedCell c = 0b00000000;
	std::fill(m_cellsVec.begin(), m_cellsVec.end(), c);
	std::fill(m_nextCellsVec.begin(), m_nextCellsVec.end(), c);

	// �Z������
	for(auto& cell : m_cells)
	{
		Vector2DInt local = { cell.first.x - minX, cell.first.y - minY };
		int index = local.y * WIDTH + local.x;
		m_cellsVec[index] = cell.second;
	}

	// --------- GPU�̃������m�� ---------- //
	size_t size = WIDTH * HEIGHT * sizeof(PackedCell);

//	cudaMalloc(&devCells, size);
//	cudaMalloc(&devNextCells, size);

	// -------- GPU�������ɓ]�� --------- //

	cudaMemcpy(devCells, m_cellsVec.data(), size, cudaMemcpyHostToDevice);


	// -------- �J�[�l���֐��̎��s -------- //

	UpdateOnGPU_CPU(devCells, devNextCells, WIDTH, HEIGHT);

	// ----------- ���ʂ̎擾 ---------- //

	cudaMemcpy(m_nextCellsVec.data(), devNextCells, size, cudaMemcpyDeviceToHost);

	// vector����map�֕ϊ�
	for (int y = 0; y < HEIGHT; ++y)
	{
		for (int x = 0; x < WIDTH; ++x)
		{
			int index = y * WIDTH + x;

			if (GetSubType(m_nextCellsVec[index]) == SUBTYPE_NONE) continue;

			Vector2DInt pos = { x + minX, y + minY };

			m_nextCells[pos] = m_nextCellsVec[index];
		}
	}

	std::swap(m_cells, m_nextCells);
}

