#pragma once

#include "Button.h"
#include "SelectUI.h"
#include "CellInfo.h"
#include "Button.h"
#include "TextBox.h"

#include "CircuitSimulator.h"
#include "CircuitEditer.h"

class LogicCircuit
{
	// �����Đ����̍X�V�Ԋu
	static constexpr float UPDATE_DISTANCE = 1.0f / 10;
	static constexpr float UPDATE_DISTANCE_FAST = 1.0f / 30;
	static constexpr float UPDATE_DISTANCE_FASTTEST = 1.0f / 1000;

	static constexpr Vector2D BUTTON_SIZE = { 50, 50 };

	std::unordered_map<std::string, std::pair<Vector2D, std::wstring>> buttonInfos =
	{
		{ "Stop"		, {{ 70 , 70},		L"��~"}},
		{ "PlayOnce"	, {{ 130, 70},		L"1����s"}},
		{ "Play"		, {{ 190, 70},		L"�Đ�"}},
		{ "PlayFast"	, {{ 250, 70},		L"������"}},
	};

private:

	// �X�e�[�W
	std::unordered_map<Vector2DInt, PackedCell> m_cells;
	std::unordered_map<Vector2DInt, PackedCell> m_nextCells;

	CircuitEditer m_circuitEditer;
	CircuitSimulator m_circuitSimulator;

	// ���s�{�^��
	std::map<std::string, std::unique_ptr<Button>> m_playButtons;
	TextBox m_textBox;

	// �X�s�[�h
	float m_nowElapsedTime;
	float m_playSpeed;

public:
	LogicCircuit();

	void Initialize();

	void Update(float elapsedTime, Vector2D cameraPos, float cameraScale);

	void Render(Vector2DInt mouseInput, Vector2D cameraPos, float scale);

private:
	// �O���b�h�̕`��
	void DrawGrid(Vector2D cameraPos, float scale);
};

