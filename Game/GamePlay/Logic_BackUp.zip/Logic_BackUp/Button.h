#pragma once

class Button
{
	int m_color;
	int m_ghButton;

	bool m_mode;

	Vector2D m_position;

	Vector2D m_size;

	bool m_isPressed;

	int m_mouseInput;
	int m_oldMouseInput;

public:
	Button(Vector2D pos, Vector2D size, bool mode, int paramator);

	void Update();

	void Render();

	bool GetIsPressed() const { return m_isPressed; }

	void ChengePos(Vector2D pos) { m_position = pos; }

	Vector2D GetPos() const { return m_position; }

	bool MouseIsOnButton();
};

