#include "CircuitEditer.h"
#include "SelectUI.h"

SelectUI::SelectUI(CircuitEditer* pParent)
	: m_pParent{ pParent }
	, m_nowState{ State::Hide }
	, m_easingX{ 0 }
	, m_position{ Screen::WIDTH, 0 }
	, m_slideButton{ {Screen::WIDTH - BUTTON_SIZE.x / 2, Screen::HEIGHT / 2}, BUTTON_SIZE, false, 0xEEEEEE }
	, m_buttons{}
{
	for(auto pos : buttonLocalPoses)
	{
		Button button(m_position + pos.second, { 80, 80 }, true, m_ghIcons[pos.first]);
		m_buttons[pos.first] = std::make_unique<Button>(std::move(button));
	}

	// �u���b�N�I���{�^���̒ǉ�
	for(int i = 0; i < Cell::BUTTONS.size(); i++)
	{
		Button button({ m_position.x + 100 + 100 * (i % 4), m_position.y + 100 + 100 * (i / 4) }, { 80, 80 }, false, Cell::COLORS[Cell::BUTTONS[i]]);
		m_blockButtons[Cell::BUTTONS[i]] = std::make_unique<Button>(std::move(button));
	}
}


void SelectUI::Initialize()
{

}

void SelectUI::Update(float elapsedTime)
{
	// �{�^���̍X�V
	m_slideButton.Update();

	// ��Ԃɂ�蕪��
	switch (m_nowState)
	{
	case State::Opening:

		// �C�[�W���O�ϐ��̉��Z
		m_easingX += elapsedTime;

		// ������
		m_position.x = Screen::WIDTH - (Screen::WIDTH * (2.0f / 5)) * EaseOutQuart(m_easingX);
		m_slideButton.ChengePos({ m_position.x - BUTTON_SIZE.x / 2, Screen::HEIGHT / 2 });

		if (m_easingX >= 1)
		{
			m_nowState = State::Exist;
			m_position.x = (Screen::WIDTH * (3.0f / 5));
			m_slideButton.ChengePos({ m_position.x - BUTTON_SIZE.x / 2, Screen::HEIGHT / 2 });
		}

		break;
	case State::Closing:

		// �C�[�W���O�ϐ��̉��Z
		m_easingX += elapsedTime;

		// ������
		m_position.x = Screen::WIDTH * (3.0f / 5) + (Screen::WIDTH * (2.0f / 5)) * EaseOutQuart(m_easingX);
		m_slideButton.ChengePos({ m_position.x - BUTTON_SIZE.x / 2, Screen::HEIGHT / 2 });

		if (m_easingX >= 1)
		{
			m_nowState = State::Hide;
			m_position.x = Screen::WIDTH;
			m_slideButton.ChengePos({ m_position.x - BUTTON_SIZE.x / 2, Screen::HEIGHT / 2 });
		}

		break;
	case State::Hide:

		// �C�[�W���O������
		m_easingX = 0;

		// �X���C�h�{�^���������ꂽ��
		if (m_slideButton.GetIsPressed())
		{
			// ��Ԃ��I�[�v����
			m_nowState = State::Opening;
		}

		break;
	case State::Exist:

		// �C�[�W���O������
		m_easingX = 0;

		// �X���C�h�{�^���������ꂽ��
		if (m_slideButton.GetIsPressed())
		{
			// ��Ԃ��N���[�Y��
			m_nowState = State::Closing;
		}

		break;
	default:
		break;
	}

	m_textBox.Update(false, { 0, 0 }, L"");

	// �ۑ��{�^���̍X�V
	for (auto& button : m_buttons)
	{
		button.second->Update();

		button.second->ChengePos(m_position + buttonLocalPoses[button.first]);

		if(button.second->MouseIsOnButton())
		{
			Vector2DInt pos;
			GetMousePoint(&pos.x, &pos.y);
			m_textBox.Update(true, { pos.x + 0.f, pos.y + 0.f }, buttonExplains[button.first]);
		}

		if(button.first == "Save")
		{
			if (button.second->GetIsPressed())
			{
				m_pParent->SaveCells(SaveFileDialog());
			}
		}
		else if(button.first == "Load")
		{
			if (button.second->GetIsPressed())
			{
				m_pParent->LoadCells(LoadFileDialog());
			}
		}
		else if(button.first == "Clear")
		{
			if (button.second->GetIsPressed()) m_pParent->Reset();
		}
		else if(button.first == "Reset")
		{
			if (button.second->GetIsPressed())
			{
				m_pParent->ChangePutMode(PutMode::Put);
			}
		}
		else if(button.first == "Copy")
		{
			if (button.second->GetIsPressed())
			{
				m_nowState = State::Closing;
				m_easingX = 0;

				m_pParent->ChangePutMode(PutMode::Copy);
			}
		}
		else if(button.first == "Paste")
		{
			if (button.second->GetIsPressed())
			{
				m_nowState = State::Closing;
				m_easingX = 0;

				m_pParent->ChangePutMode(PutMode::Paste);
			}
		}
		else if(button.first == "Range")
		{
			if (button.second->GetIsPressed())
			{
				m_nowState = State::Closing;
				m_easingX = 0;

				m_pParent->ChangePutMode(PutMode::Range);
			}
		}
		else if(button.first == "Horizontal")
		{
			if (button.second->GetIsPressed())
			{
				m_nowState = State::Closing;
				m_easingX = 0;

				m_pParent->CopyInversion(true);
			}
		}
		else if(button.first == "Vertical")
		{
			if (button.second->GetIsPressed())
			{
				m_nowState = State::Closing;
				m_easingX = 0;

				m_pParent->CopyInversion(false);
			}
		}
	}

	// �u���b�N�I���{�^���̍X�V
	for(int i = 0; i < m_blockButtons.size(); i++)
	{
		// �{�^���̍X�V
		m_blockButtons[Cell::BUTTONS[i]]->Update();

		// �ʒu�̍X�V
		m_blockButtons[Cell::BUTTONS[i]]->ChengePos({ m_position.x + 100 + 100 * (i % 4), m_position.y + 100 + 100 * (i / 4) });

		if (m_blockButtons[Cell::BUTTONS[i]]->GetIsPressed()) m_pParent->ChangePutType(Cell::BUTTONS[i]);

		if(m_blockButtons[Cell::BUTTONS[i]]->MouseIsOnButton())
		{
			Vector2DInt pos;
			GetMousePoint(&pos.x, &pos.y);
			m_textBox.Update(true, { pos.x + 0.f, pos.y + 0.f }, blockButtonExplains[Cell::BUTTONS[i]]);
		}
	}
}

void SelectUI::Render()
{
	// �{�^���̕`��
	m_slideButton.Render();

	DrawBox(m_position.x, m_position.y, Screen::WIDTH, Screen::HEIGHT, 0x333333, true);

	for (auto& button : m_buttons) button.second->Render();
	for (auto& button : m_blockButtons) button.second->Render();

	if(m_nowState == State::Exist) m_textBox.Render(false);
}

bool SelectUI::GetInSelectUI(Vector2DInt screenPos)
{
	Vector2D buttonPos = m_slideButton.GetPos();

	bool a = (screenPos.x > m_position.x && screenPos.x < Screen::WIDTH) && (screenPos.y > m_position.y && screenPos.y < Screen::HEIGHT);
	bool b = (screenPos.x > buttonPos.x - BUTTON_SIZE.x && screenPos.x < buttonPos.x + BUTTON_SIZE.x) && (screenPos.y > buttonPos.y - BUTTON_SIZE.y && screenPos.y < buttonPos.y + BUTTON_SIZE.y);

	bool c = (m_nowState == State::Closing || m_nowState == State::Opening);

	return a || b || c;
}

void SelectUI::SetState(State state)
{
	switch (state)
	{
		// �J�ڌオ�J�����Ȃ�
	case State::Opening:
		// �B��Ă��Ȃ���Ζ���
		if (m_nowState != State::Hide) return;
		m_nowState = State::Opening;
		break;
	case State::Closing:
		// �J�ڌオ�����Ȃ�
		if (m_nowState != State::Exist) return;
		m_nowState = State::Closing;
		break;
	case State::Hide:
		// �J�ڌオ�B���Ȃ�
		if (m_nowState == State::Exist) m_nowState = State::Closing;
		break;
	case State::Exist:
		// �J�ڌオ���݂�����
		if (m_nowState == State::Hide) m_nowState = State::Opening;
		break;
	default:
		break;
	}
}

std::wstring SelectUI::SaveFileDialog()
{
	wchar_t filename[MAX_PATH];
	filename[0] = L'\0'; // �ŏ��Ƀk����������Ă���

	OPENFILENAME ofn;
	// ofn����n�܂�sizeof(ofn)���̃�������0�Ŗ��߂�
	ZeroMemory(&ofn, sizeof(ofn));

	// �\���̂̒������w��
	ofn.lStructSize = sizeof(ofn);

	ofn.hInstance;

	// �t�B���^�[������̃o�b�t�@�[
	ofn.lpstrFilter = L"�X�e�[�W\0*.txt\0���ׂẴt�@�C��\0*.*\0";

	TCHAR szCustomFilter[256] = L"";

	ofn.lpstrCustomFilter = szCustomFilter;
	ofn.nMaxCustFilter = sizeof(szCustomFilter);

	ofn.hwndOwner = NULL;
	ofn.lpstrFile = filename;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrInitialDir = L"Resources/Stages";
	ofn.lpstrDefExt = _T("csv");
	ofn.nFilterIndex = 2; // �����I�Ɏw��
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
	ofn.lpstrTitle = L"�X�e�[�W��ۑ�";

	if (GetOpenFileNameW(&ofn))
	{
		return std::wstring(filename);
	}

	return L"";
}

std::wstring SelectUI::LoadFileDialog()
{
	wchar_t filename[MAX_PATH];
	filename[0] = L'\0'; // �ŏ��Ƀk����������Ă���

	OPENFILENAME ofn;
	// ofn����n�܂�sizeof(ofn)���̃�������0�Ŗ��߂�
	ZeroMemory(&ofn, sizeof(ofn));

	// �\���̂̒������w��
	ofn.lStructSize = sizeof(ofn);

	ofn.hInstance;

	// �t�B���^�[������̃o�b�t�@�[
	ofn.lpstrFilter = L"�X�e�[�W\0*.txt\0���ׂẴt�@�C��\0*.*\0";

	TCHAR szCustomFilter[256] = L"";

	ofn.lpstrCustomFilter = szCustomFilter;
	ofn.nMaxCustFilter = sizeof(szCustomFilter);

	ofn.hwndOwner = NULL;
	ofn.lpstrFile = filename;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrInitialDir = L"Resources/Stages";
	ofn.lpstrDefExt = _T("csv");
	ofn.nFilterIndex = 2; // �����I�Ɏw��
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
	ofn.lpstrTitle = L"�X�e�[�W�����[�h";

	if (GetOpenFileNameW(&ofn))
	{
		return std::wstring(filename);
	}

	return L"";
}
