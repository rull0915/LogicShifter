#pragma once
#include "CellInfo.h"
#include "CircuitSimulator.cuh"

class CircuitSimulator
{
	// �X�e�[�W�̎Q��
	std::unordered_map<Vector2DInt, PackedCell>& m_cells;
	std::unordered_map<Vector2DInt, PackedCell>& m_nextCells;

	// GPU�ɓn���p�̔z��
	std::vector<PackedCell> m_cellsVec;
	std::vector<PackedCell> m_nextCellsVec;

	// GPU�p
	PackedCell* devCells;
	PackedCell* devNextCells;

public:
	CircuitSimulator(std::unordered_map<Vector2DInt, PackedCell>& cells, std::unordered_map<Vector2DInt, PackedCell>& nextCells);
	~CircuitSimulator() {
		cudaFree(devCells);
		cudaFree(devNextCells);
	}

	void Initialize();

	void ToNextCells();
};

