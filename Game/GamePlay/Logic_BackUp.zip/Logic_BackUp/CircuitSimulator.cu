#include "CircuitSimulator.cuh"
#include "cuda_runtime.h"
#include "device_launch_parameters.h"

__global__ void UpdateOnGPU(PackedCell* cells, PackedCell* nextCells, int width, int height)
{
	int x = blockIdx.x * blockDim.x + threadIdx.x;
	int y = blockIdx.y * blockDim.y + threadIdx.y;

	int index = y * width + x;

	if (x >= width || y >= height) return;

	// �M��
	bool aroundUp = false, aroundDown = false, aroundLeft = false, aroundRight = false;

	// �אڃZ��
	PackedCell cUp = getCellSafe(cells, width, height, x, y - 1);
	PackedCell cDown = getCellSafe(cells, width, height, x, y + 1);
	PackedCell cLeft = getCellSafe(cells, width, height, x - 1, y);
	PackedCell cRight = getCellSafe(cells, width, height, x + 1, y);
	PackedCell cNow = cells[index];

	// �ϊ���̃Z��
	PackedCell nC = 0;

	SetType(nC, GetType(cNow));
	SetSubType(nC, GetSubType(cNow));

	switch (GetType(cNow))
	{
		// �����̏ꍇ
	case TYPE_WIRE:

		aroundLeft = (GetLeftSignal(cRight));   // �E�Z�����������M��
		aroundRight = (GetRightSignal(cLeft));  // ���Z�����E����
		aroundDown = (GetUpSignal(cDown));     // ���Z���������
		aroundUp = (GetDownSignal(cUp));   // ��Z����������
		break;

	case TYPE_OTHERS:
		nC = cNow;
		break;

	case TYPE_INPUT:

		switch (GetSubType(cNow))
		{
		case SUBTYPE_AND:

			aroundUp =(GetType(cUp) == TYPE_WIRE ? GetDownSignal(cUp) : true);
			aroundDown = (GetType(cDown) == TYPE_WIRE ? GetUpSignal(cDown) : true);
			aroundRight = (GetType(cRight) == TYPE_WIRE ? GetLeftSignal(cRight) : true);
			aroundLeft = (GetType(cLeft) == TYPE_WIRE ? GetRightSignal(cLeft) : true);

			break;

		case SUBTYPE_OR:
		case SUBTYPE_XOR:

			aroundUp = (GetType(cUp) == TYPE_WIRE ? GetDownSignal(cUp) : false);
			aroundDown = (GetType(cDown) == TYPE_WIRE ? GetUpSignal(cDown) : false);
			aroundRight = (GetType(cRight) == TYPE_WIRE ? GetLeftSignal(cRight) : false);
			aroundLeft = (GetType(cLeft) == TYPE_WIRE ? GetRightSignal(cLeft) : false);

			break;

		default:
			break;
		}

		break;

	case TYPE_OUTPUT:

		aroundUp = (GetType(cUp) == TYPE_INPUT && GetDownSignal(cUp));
		aroundDown = (GetType(cDown) == TYPE_INPUT && GetUpSignal(cDown));
		aroundRight = (GetType(cRight) == TYPE_INPUT && GetLeftSignal(cRight));
		aroundLeft = (GetType(cLeft) == TYPE_INPUT && GetRightSignal(cLeft));

		break;

	default:
		break;
	}

	bool signal = false;

	switch (GetType(cNow))
	{
	case TYPE_WIRE:

		switch (GetSubType(cNow))
		{
		case SUBTYPE_NORMAL:

			// �M�����󂯎�邩�ǂ���
			if (aroundDown || aroundUp || aroundLeft || aroundRight)
			{
				// ���[�v�h�~����
				SetUpSignal(nC, !GetDownSignal(cUp));
				SetDownSignal(nC, !GetUpSignal(cDown));
				SetRightSignal(nC, !GetLeftSignal(cRight));
				SetLeftSignal(nC,!GetRightSignal(cLeft));
			}
			else
			{
				// ���[�v�h�~����
				SetUpSignal(nC, false);
				SetDownSignal(nC, false);
				SetRightSignal(nC, false);
				SetLeftSignal(nC,false);
			}

			break;

		case SUBTYPE_CROSS:

			SetType(nC, TYPE_WIRE);
			SetSubType(nC, SUBTYPE_CROSS);

			// �M���`�F�b�N
			SetUpSignal(nC, (aroundUp || aroundDown) && !GetDownSignal(cUp));
			SetDownSignal(nC, (aroundUp || aroundDown) && !GetUpSignal(cDown));
			SetRightSignal(nC, (aroundLeft || aroundRight) && !GetLeftSignal(cRight));
			SetLeftSignal(nC,(aroundLeft || aroundRight) && !GetRightSignal(cLeft));

			break;

		default:
			break;
		}

		break;
	case TYPE_INPUT:

		SetType(nC, TYPE_INPUT);

		switch (GetSubType(cNow))
		{
			// �A���h�Z���̏ꍇ
		case SUBTYPE_AND:

			SetSubType(nC, SUBTYPE_AND);

			signal = ((aroundUp && aroundDown) && (aroundLeft && aroundRight));

			break;
		case SUBTYPE_OR:

			SetSubType(nC, SUBTYPE_OR);

			signal = ((aroundUp || aroundDown) || (aroundLeft || aroundRight));

			break;
		case SUBTYPE_XOR:

			SetSubType(nC, SUBTYPE_XOR);

			signal = (aroundUp + aroundDown + aroundLeft + aroundRight) % 2 == 1;

			break;
		default:
			break;
		}

		// �M���`�F�b�N
		if (signal)
		{
			SetUpSignal(nC, GetType(cUp) == TYPE_OUTPUT);
			SetDownSignal(nC, GetType(cDown) == TYPE_OUTPUT);
			SetRightSignal(nC, GetType(cRight) == TYPE_OUTPUT);
			SetLeftSignal(nC, GetType(cLeft) == TYPE_OUTPUT);
		}

		break;
	case TYPE_OUTPUT:

		SetType(nC, TYPE_OUTPUT);

		switch (GetSubType(cNow))
		{
		case SUBTYPE_NORMAL:
			signal = ((aroundUp || aroundDown) || (aroundLeft || aroundRight));
			SetSubType(nC, SUBTYPE_NORMAL);
			break;
		case SUBTYPE_NOT:
			signal = !((aroundUp || aroundDown) || (aroundLeft || aroundRight));
			SetSubType(nC, SUBTYPE_NOT);
			break;
		default:
			break;
		}

		if (signal)
		{
			SetUpSignal(nC, GetType(cUp) == TYPE_WIRE);
			SetDownSignal(nC, GetType(cDown) == TYPE_WIRE);
			SetRightSignal(nC, GetType(cRight) == TYPE_WIRE);
			SetLeftSignal(nC, GetType(cLeft) == TYPE_WIRE);
		}

		break;
	default:
		break;
	}

	// �R�s�[
	nextCells[index] = nC;
}

void UpdateOnGPU_CPU(PackedCell* devCells, PackedCell* devNextCells, int width, int height)
{
	dim3 block(16, 16);
	dim3 grid((width + block.x - 1) / block.x, (height + block.y - 1) / block.y);
	UpdateOnGPU << <grid, block >> > (devCells, devNextCells, width, height);
	cudaDeviceSynchronize();
}

__device__ __forceinline__ PackedCell getCellSafe(PackedCell* cells, int width, int height, int x, int y)
{
	if (x < 0 || x >= width || y < 0 || y >= height) return 0b00000000;
	return cells[y * width + x];
}
