#pragma once
#include "Cell.h"

#include "CircuitSimulator.cuh"
#include "cuda_runtime.h"
#include "device_launch_parameters.h"

// GPU�X�V�֐����O������Ăׂ�悤�ɐ錾
__global__ void UpdateOnGPU(PackedCell* devCells, PackedCell* devNextCells, int width, int height);

void UpdateOnGPU_CPU(PackedCell* devCells, PackedCell* devNextCells, int width, int height);

__device__ __forceinline__ PackedCell getCellSafe(PackedCell* cells, int width, int height, int x, int y);
