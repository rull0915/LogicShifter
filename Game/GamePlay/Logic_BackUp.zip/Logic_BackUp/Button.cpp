#include "Button.h"

Button::Button(Vector2D pos, Vector2D size, bool mode, int paramator)
	: m_position{ pos }
	, m_size{ size }
	, m_mode{ mode }
	, m_color{ 0 }
	, m_ghButton{ -1 }
{
	if (m_mode)
	{
		m_ghButton = paramator;
	}
	else m_color = paramator;
}

void Button::Update()
{
	m_oldMouseInput = m_mouseInput;
	m_mouseInput = GetMouseInput();

	m_isPressed = false;

	if((~m_oldMouseInput & m_mouseInput) & MOUSE_INPUT_LEFT)
	{
		Vector2DInt pos;
		GetMousePoint(&pos.x, &pos.y);

		if ((pos.x > m_position.x - m_size.x / 2 && pos.x < m_position.x + m_size.x / 2) &&
			(pos.y > m_position.y - m_size.y / 2 && pos.y < m_position.y + m_size.y / 2)) m_isPressed = true;
	}

}

void Button::Render()
{
	if(m_mode)
	{
		DrawExtendGraph(m_position.x - m_size.x / 2, m_position.y - m_size.y / 2, m_position.x + m_size.x / 2, m_position.y + m_size.y / 2, m_ghButton, true);
	}
	else
	{
//		MyDrawRoundBox(m_position - m_size / 2, m_position + m_size / 2, m_size.x / 8, m_color, true);
		DrawBox(m_position.x - m_size.x / 2, m_position.y - m_size.y / 2, m_position.x + m_size.x / 2, m_position.y + m_size.y / 2, m_color, true);
	}

	if(m_isPressed)
	{
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, 128);
		DrawBox(m_position.x - m_size.x / 2, m_position.y - m_size.y / 2, m_position.x + m_size.x / 2, m_position.y + m_size.y / 2, 0xffffff, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	}

	Vector2DInt pos;
	GetMousePoint(&pos.x, &pos.y);
}

bool Button::MouseIsOnButton()
{
	Vector2DInt pos;
	GetMousePoint(&pos.x, &pos.y);
	return ((pos.x > m_position.x - m_size.x / 2 && pos.x < m_position.x + m_size.x / 2) &&
		(pos.y > m_position.y - m_size.y / 2 && pos.y < m_position.y + m_size.y / 2));
}
